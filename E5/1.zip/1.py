name = str(input())
print("How Are You " + name)